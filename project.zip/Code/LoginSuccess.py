from tkinter import *                                 
from PIL import Image,ImageTk
from tkinter import ttk
from tkinter import messagebox
import datetime
class Success:      
    def __init__(self,window):
#=======Creating_Geometry============================================================================================
#====================================================================================================================
        self.window = window
        self.window.title("Student Information")
        self.window.geometry('1150x700+0+0')
        self.window.resizable("false","false")
        self.showLab = Label(self.window,text="WELCOME",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=8,width=250)
