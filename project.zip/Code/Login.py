from logging import info
from tkinter.font import names
from LoginSuccess import Success
from tkinter import *
from tkinter import ttk
from register_info import Info
import os
import cv2
from PIL import Image
import numpy as np
import sys

#from interface.foods import fod
# from interface.Grocery import Grocery_System
# from interface.Admin import Admin_System
from PIL import Image,ImageTk
import datetime
from tkinter import messagebox
class Sign:
    def __init__(self,new_window):

#===Sign_In_Window====================================================================================================:
#=======To_Close_Previous_Window======================================================================================
        #self.window.withdraw()
        self.new_window=new_window
        self.new_window.title("Sign_in")
        self.new_window.geometry('900x750+0+0')
        self.new_window.resizable("false","false")


        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.new_window, font=('times new roman', 12), fg='black', bg="White", text=self.date)
            self.clock_label.place(x=700, y=100)
            self.clock_label.after(200, time)
        time()
#=======Importing_Class_Of_Register_Info=============================================================================
        self.info=Info()
        
        # campicname = self.info.
        # a = self.info.babu
        # print(a)
#=======For_Reset=====================================================================================================
        self.user_reset = StringVar()
        self.password_reset = StringVar()

#=======Adding_Background_Image=======================================================================================
        self.bg = ImageTk.PhotoImage(file="C:\\Users\\Dell\\Music\\NowBegins\\Images\\sign_in.jpg")
        bg = Label(self.new_window, image=self.bg).place(x=0, y=0, relwidth=1, relheight=1)

        self.user_name_entry = Entry(self.new_window,font=("times new roman",15), highlightbackground="black",highlightthickness="1",textvariable=self.user_reset)
        self.user_name_entry.place(x=380,y=490)

        self.user_password_entry = Entry(self.new_window, font=("times new roman", 15), show='*',fg="red",highlightbackground='black',highlightthickness="1",textvariable=self.password_reset)
        self.user_password_entry.place(x=380, y=575)

        self.login_button = Button(self.new_window,cursor="hand2",text="L   o   g   i   n",borderwidth=0,bg="White",font=("times new roman",15,"bold"),command=self.Login)
        self.login_button.place(x=560,y=630)

        self.lb1 = Label(self.new_window,text="D o n ' t  h a v e   a c c o u n t ?",font=("times new roman",9),bg="White")
        self.lb1.place(x=640,y=680)

        self.sign_up = Button(self.new_window,cursor="hand2",text="S i g n  U p",borderwidth=0,bg="White",fg="Red",font=("times new roman",10,"bold"),command=self.sign_up)
        self.sign_up.place(x=700,y=700)

        def enter(e):
            self.image2 = PhotoImage(file = "C:\\Users\\Dell\\Music\\NowBegins\\Images\\state2.png")
            self.shy_label["image"] = self.image2
            self.shy_label.image = self.image2
        def enterpas(e):
            self.image2 = PhotoImage(file="C:\\Users\\Dell\\Music\\NowBegins\\Images\\state3.png")
            self.shy_label["image"] = self.image2
            self.shy_label.image = self.image2
        def leave(e):
            self.image1 = PhotoImage(file="C:\\Users\\Dell\\Music\\NowBegins\\Images\\state1.png")
            self.shy_label["image"] = self.image1
            self.shy_label.image = self.image1

        self.im = PhotoImage(file="C:\\Users\\Dell\\Music\\NowBegins\\Images\\state1.png")
        self.shy_label = Label(self.new_window,image=self.im,bg="green",font=("times new roman",15,"bold"))
        self.shy_label.image = self.im
        self.shy_label.place(x=290,y=165,width=310,height=320)

        self.user_name_entry.bind("<Enter>",enter)
        self.user_name_entry.bind("<Leave>",leave)

        self.user_password_entry.bind("<Enter>",enterpas)
        self.user_password_entry.bind("<Leave>",leave)


        self.reset_button = Button(self.new_window,cursor="hand2",text="R  e  s  e  t", bg="White",borderwidth=0, font=("times new roman", 15, "bold"),command=self.reset_signIn)
        self.reset_button.place(x=280, y=630)

        self.combo_box_usertypes = ttk.Combobox(self.new_window,font=("times new roman", 15),state="readonly",justify=CENTER)
        self.combo_box_usertypes.place(x=350,y=130,width=210,height=30)
        self.combo_box_usertypes["values"] = ("Select","Admin","Employment")

#=======To_Focus_In_Only_One_Windows==================================================================================
        self.new_window.grab_set()

#=======get()=========================================================================================================
        self.user = self.user_name_entry.get()
        self.pas = self.user_password_entry.get()

    def Login(self):
        if self.user_name_entry.get() == "" or self.user_password_entry.get() == "":
            messagebox.showerror("Error","Please fill all the entries")
            return TRUE
        else:
            if self.combo_box_usertypes.get() == "Employment":
                self.new_window.withdraw()
                name = self.user_name_entry.get()
                password = self.user_password_entry.get()
                self.info.Login(name,password)
                self.user_name_entry.delete(0,END)
                self.user_password_entry.delete(0,END)
                self.namdekhanamdekha = self.info.manche
                self.namdekha2 = str(self.namdekhanamdekha)
                # print(self.namdekha2)
#===========To_Open_Grocery_Management_System==========================================================================

                def grocery():
                    LoginSuccessWindow = Toplevel(self.new_window)
                    messagebox.showinfo("Success","Welcome to ......................")
                    Success(LoginSuccessWindow)
                    
                
                        
                # return False


                def draw_boundary(img, classifier, scaleFactor, minNeighbors, color, text, clf):
                    gray_img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                    features = classifier.detectMultiScale(gray_img,scaleFactor,minNeighbors)
                    for (x,y,w,h) in features:
                        cv2.rectangle(img,(x,y),(x+w,y+h),color,2)
                        id, pred = clf.predict(gray_img[y:y+h,x:x+w])
                        confidence = int(100*(1-pred/300))
                        if confidence>75 and id == int(name):
                            cv2.putText(img,self.namdekha2, (x,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.8,color,1,cv2.LINE_AA)
                            # cv2.waitKey(5000)
                            # messagebox.showinfo("Verified","User verified")
                            # video_capture.release()
                            # cv2.destroyAllWindows()
                            # grocery()

                        else:   
                            cv2.putText(img,"Unknown", (x,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.8,color,1,cv2.LINE_AA)
                            # messagebox.showerror("Error","Unknown Faces")
                            # sys.exit()

                    return img
                faceCascade = cv2.CascadeClassifier("C:\\Users\\Dell\\Music\\NowBegins\\CascadeFile\\haarcascade_frontalface_default.xml")
                clf = cv2.face.LBPHFaceRecognizer_create()
                clf.read(name + ".xml")
                video_capture = cv2.VideoCapture(0)

                while True:
                    ret, img = video_capture.read()
                    img = draw_boundary(img,faceCascade, 1.3,6,(255,255,255),"Face",clf)
                    cv2.imshow("Face Detection",img)
                    if cv2.waitKey(1) == 13:
                        break
                video_capture.release()
                cv2.destroyAllWindows()


                

    def reset_signIn(self):
        self.user_reset.set('')
        self.password_reset.set('')
        self.combo_box_usertypes.set('')
    def sign_up(self):
        self.new_window.withdraw()
        from SignUps import SignUp
        self.sign = Toplevel(self.new_window)
        SignUp(self.sign)

    




def main():
    window = Tk()
    obj = Sign(window)
    window.mainloop()
if __name__ == '__main__':
    main()