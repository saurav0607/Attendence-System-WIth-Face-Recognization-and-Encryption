import mysql.connector
class MyDb:
    def __init__(self):
        self.my_connection = mysql.connector.connect(user="root", password="root", host="localhost", database='project')
        self.my_cursor = self.my_connection.cursor()

    def iud(self,qry,values):
        self.my_cursor.execute(qry,values)
        self.my_connection.commit()
        #self.result=self.my_cursor.fetchall()

    def user_pass_check(self,qry,values):
        self.my_cursor.execute(qry, values)
        self.my_connection.commit()
        #self.result=self.my_cursor.fetchall()

    def show_data(self,qry):
        self.my_cursor.execute(qry)
        data = self.my_cursor.fetchall()
        return data

