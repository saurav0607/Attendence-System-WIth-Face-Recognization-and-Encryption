from tkinter import *                                 
from PIL import Image,ImageTk
from tkinter import ttk
from tkinter import messagebox
from register_info import Info
from attendence_database import Attend
import datetime
import os
import cv2
import numpy as np
from PIL import Image
import datetime
class Success:      
    def __init__(self,window):
#=======Creating_Geometry============================================================================================
#====================================================================================================================
        self.window = window
        self.window.title("Student Information")
        self.window.geometry('1500x810+0+0')
        self.window.resizable("false","false")
        self.showLab = Label(self.window,text="WELCOME",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=575,y=8,width=250)

        self.userid = 78
        self.closecam = []

        self.info=Info()
        self.infoattend = Attend()

        # self.info2=std_num()
        # print(self.info2.user_name_entry.get())
        with open('users.txt') as f:
            data = f.read()

        self.info.details_show(int(data))
        

        if os.path.exists("users.txt"):
            os.remove("users.txt")

        # for date
        self.e = datetime.datetime.now()
        self.date = "%s/%s/%s" % (self.e.day, self.e.month, self.e.year)
        self.time = "%s:%s:%s" % (self.e.hour, self.e.minute, self.e.second)

        self.namdekhanamdekha = self.info.manche
        self.namdekha2 = (self.namdekhanamdekha)
        print(self.namdekha2)
        self.nameforcam = self.namdekha2[0][4]
        self.idforcam = self.namdekha2[0][0]
        # print(self.nameforcam)
        print(len(self.idforcam))


        self.showLab = Label(self.window,text="Name:",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=100,width=250)


        self.showLab = Label(self.window,text=self.namdekha2[0][4],bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=325,y=100,width=250)

        self.showLab = Label(self.window,text="Student_Id:",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=200,width=250)

        self.showLab = Label(self.window,text=self.namdekha2[0][0],bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=325,y=200,width=250)

        self.showLab = Label(self.window,text="Phone:",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=300,width=250)

        self.showLab = Label(self.window,text=self.namdekha2[0][1],bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=325,y=300,width=250)

        self.showLab = Label(self.window,text="Gender:",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=400,width=250)

        self.showLab = Label(self.window,text=self.namdekha2[0][2],bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=325,y=400,width=250)
        
        self.showLab = Label(self.window,text="Address:",bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=0,y=500,width=250)
        
        self.showLab = Label(self.window,text=self.namdekha2[0][3],bg="white",fg="green",font=("times new roman",20,"bold"))
        self.showLab.place(x=325,y=500,width=250)

        self.bttn_attendence = Button(self.window,activeforeground="Red",activebackground="White", text="T a k e   A t t e n d e n c e",cursor="hand2",bg="White",borderwidth=0,font=("times new roman", 15,"bold"),command=self.attendence)
        self.bttn_attendence.place(x=650, y=550, width=300)
        

        self.item_tree1 = ttk.Treeview(self.window, columns=('SN_NO', 'DATE', 'TIME', 'STD_ID'))
        self.item_tree1.place(x=650, y=100, width=800, height=440)
        self.item_tree1['show'] = 'headings'
        self.item_tree1.column('SN_NO', width=50)
        self.item_tree1.column('DATE', width=150)
        self.item_tree1.column('TIME', width=150)
        self.item_tree1.column('STD_ID', width=100)
        # self.item_tree1.column('total_price', width=50)

        self.item_tree1.heading('SN_NO', text="Serial No")
        self.item_tree1.heading('DATE', text="Attend Date")
        self.item_tree1.heading('TIME', text="Attend Time")
        self.item_tree1.heading('STD_ID', text="Student ID")
        # self.item_tree1.heading('total_price', text="Total_Price")
        
    def attendence(self):
        self.infoattend.FindDate(self.idforcam,self.date)
        # print(self.infoattend.datesss[0][0])
        print(self.date)
        print(self.date)

        # if self.infoattend.datesss == "":
        #     runboun()
        

        

        if self.infoattend.datesss != "":     
            if str(self.date) == str(self.infoattend.datesss[0][0]):       
                messagebox.showerror("Error","Attendence was already taken!")
        # if self.infoattend.datesss !="":     
        #     self.runboun()
        #     # pass
    def runboun(self):
        def draw_boundary(img, classifier, scaleFactor, minNeighbors, color, text, clf):
            gray_img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            features = classifier.detectMultiScale(gray_img,scaleFactor,minNeighbors)
            for (x,y,w,h) in features:
                cv2.rectangle(img,(x,y),(x+w,y+h),color,2)
                id, pred = clf.predict(gray_img[y:y+h,x:x+w])
                confidence = int(100*(1-pred/300))
                if confidence>75:
                    if id == int(self.idforcam):
                        cv2.putText(img,self.nameforcam, (x,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.8,color,1,cv2.LINE_AA)
                        if cv2.waitKey(1) == 13:
                            self.infoattend.Attendence(self.date,self.time,self.idforcam)
                            messagebox.showinfo("Success","Attendence taken successfully!")
                            cv2.destroyAllWindows()
                            vide_capture.release()
                            cv2.destroyAllWindows()
                            self.closecam.append(4)
                            # vide_capture.release()
                            # cv2.destroyAllWindows()
                            # break

                else:
                    cv2.putText(img,"UNKNOWN", (x,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,0,255),1,cv2.LINE_AA) 
            return img
        faceCascade = cv2.CascadeClassifier("CascadeFile\\haarcascade_frontalface_default.xml")
        clf = cv2.face.LBPHFaceRecognizer_create()
        clf.read(self.idforcam+".xml")
        vide_capture = cv2.VideoCapture(0)
        while True:
            ret, img = vide_capture.read()
            img = draw_boundary(img,faceCascade, 1.3,6,(255,255,255),"Face",clf)
            cv2.imshow("Face Detection",img)
            if 4 in self.closecam:
                vide_capture.release()
                cv2.destroyAllWindows()
                break
            if cv2.waitKey(1) == 13:
                
                break
        vide_capture.release()
        cv2.destroyAllWindows()
    # runboun()
    # self.runbown()




# def main():
#     window = Tk()
#     obj = Success(window)
#     window.mainloop()
# if __name__ == '__main__':
#     main()