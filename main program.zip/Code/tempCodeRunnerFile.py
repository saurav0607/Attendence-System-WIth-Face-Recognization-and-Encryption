


def main():
    window = Tk()